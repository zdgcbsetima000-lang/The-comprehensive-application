تجهيز رفيق القرآن للنشر على Galaxy Store

1) ارفع المشروع إلى GitHub.
2) شغّل GitHub Actions لبناء APK أو AAB.
3) قبل النشر النهائي، أنشئ توقيع Release ثابت (Keystore) واحتفظ به في مكان آمن.
4) لا تغيّر applicationId أو مفتاح التوقيع بين تحديث وآخر حتى يستطيع المستخدمون استلام التحديثات.
5) راجع STORE_LISTING_AR.md وجهّز صورًا حقيقية من التطبيق.
6) انشر docs/privacy_policy.html على GitHub Pages أو استضافة عامة واستخدم رابطها في بيانات المتجر.
7) ارفع ملف الإصدار الناتج إلى Galaxy Store Seller Portal وأكمل بيانات التطبيق والتصنيف والدول.

مهم: قبل المراجعة النهائية اختبر القراءة والصوت والأذكار على هاتف حقيقي.

==============================
طريقة البناء على GitHub (جاهزة)
==============================
1) أنشئ Repository جديد على GitHub.
2) ارفع محتويات هذا المشروع كما هي. الأفضل رفع الملفات بعد فك ZIP.
3) ملف Workflow موجود بالفعل في:
   .github/workflows/main.yml
4) افتح تبويب Actions وشغّل Build Rafiq Al-Quran APK and AAB.
5) بعد انتهاء البناء حمّل APK و AAB من Artifacts.

اسم التطبيق: رفيق القرآن
اسم Flutter: rafiq_al_quran
Android Application ID المستهدف: com.rafiqalquran.app
