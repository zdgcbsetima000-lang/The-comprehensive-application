from pathlib import Path

p = Path('android/app/build.gradle.kts')
if p.exists():
    s = p.read_text()
    if 'val keystorePropertiesFile = rootProject.file("key.properties")' not in s:
        marker = 'plugins {'
        inject = '''import java.util.Properties

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(keystorePropertiesFile.inputStream())
}

'''
        s = s.replace(marker, inject + marker, 1)
    if 'signingConfigs {' not in s:
        anchor = 'android {'
        s = s.replace(anchor, anchor + '''
    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = keystoreProperties["storeFile"]?.let { file(it) }
            storePassword = keystoreProperties["storePassword"] as String
        }
    }
''', 1)
    s = s.replace('buildTypes {\n        release {', 'buildTypes {\n        release {\n            signingConfig = signingConfigs.getByName("release")')
    p.write_text(s)
    raise SystemExit(0)

p = Path('android/app/build.gradle')
s = p.read_text()
if 'keystorePropertiesFile' not in s:
    inject = '''def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

'''
    s = inject + s
if 'signingConfigs {' not in s:
    s = s.replace('android {', '''android {
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
''', 1)
s = s.replace('buildTypes {\n        release {', 'buildTypes {\n        release {\n            signingConfig signingConfigs.release')
p.write_text(s)
