package com.rafiqalquran.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
