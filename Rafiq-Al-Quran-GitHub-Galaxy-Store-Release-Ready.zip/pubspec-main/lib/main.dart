import 'dart:convert';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const _navy = Color(0xFF0D1B2A);
const _navy2 = Color(0xFF172D46);
const _cream = Color(0xFFF7F2E8);
const _gold = Color(0xFFD8B36A);
const _blue = Color(0xFF5E8FC6);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(QuranAzkarApp(prefs: prefs));
}

class QuranAzkarApp extends StatefulWidget {
  final SharedPreferences prefs;
  const QuranAzkarApp({super.key, required this.prefs});

  @override
  State<QuranAzkarApp> createState() => _QuranAzkarAppState();
}

class _QuranAzkarAppState extends State<QuranAzkarApp> {
  bool get dark => widget.prefs.getBool('dark') ?? false;

  @override
  Widget build(BuildContext context) {
    final base = ThemeData(
      useMaterial3: true,
      brightness: dark ? Brightness.dark : Brightness.light,
      scaffoldBackgroundColor: dark ? const Color(0xFF09131F) : _cream,
      colorScheme: ColorScheme.fromSeed(
        seedColor: _gold,
        brightness: dark ? Brightness.dark : Brightness.light,
      ),
      textTheme: GoogleFonts.cairoTextTheme(),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'رفيق القرآن',
      theme: base,
      home: widget.prefs.getBool('onboardingDone') == true
          ? MainNavigationScreen(
              prefs: widget.prefs,
              onThemeChanged: () => setState(() {}),
            )
          : OnboardingScreen(prefs: widget.prefs, onFinished: () => setState(() {})),
    );
  }
}

class OnboardingScreen extends StatefulWidget {
  final SharedPreferences prefs;
  final VoidCallback onFinished;
  const OnboardingScreen({super.key, required this.prefs, required this.onFinished});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController controller = PageController();
  int page = 0;
  final slides = const [
    ('رفيق القرآن', 'اقرأ وتدبر واجعل القرآن نورًا يرافق يومك', Icons.menu_book_rounded),
    ('كل عبادتك في مكان واحد', 'القرآن، الأذكار، مواقيت الصلاة، التسبيح والمفضلة', Icons.auto_awesome_rounded),
    ('ابدأ رحلتك بهدوء', 'تجربة عربية أنيقة صُممت لتساعدك على الاستمرار', Icons.nightlight_round),
  ];

  Future<void> finish() async {
    await widget.prefs.setBool('onboardingDone', true);
    widget.onFinished();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _navy,
        body: SafeArea(
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton(
                  onPressed: finish,
                  child: const Text('تخطي', style: TextStyle(color: Colors.white70)),
                ),
              ),
              Expanded(
                child: PageView.builder(
                  controller: controller,
                  itemCount: slides.length,
                  onPageChanged: (v) => setState(() => page = v),
                  itemBuilder: (_, i) {
                    final s = slides[i];
                    return Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 180,
                            height: 180,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const LinearGradient(colors: [_gold, Color(0xFF8B6A35)]),
                              boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 30)],
                            ),
                            child: Icon(s.$3, size: 88, color: _navy),
                          ),
                          const SizedBox(height: 42),
                          Text(s.$1, style: GoogleFonts.amiri(fontSize: 40, color: Colors.white, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 14),
                          Text(s.$2, textAlign: TextAlign.center, style: GoogleFonts.cairo(fontSize: 16, height: 1.8, color: Colors.white70)),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(slides.length, (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.all(4),
                  width: i == page ? 26 : 8,
                  height: 8,
                  decoration: BoxDecoration(color: i == page ? _gold : Colors.white24, borderRadius: BorderRadius.circular(20)),
                )),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(28, 18, 28, 30),
                child: SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: _gold, foregroundColor: _navy),
                    onPressed: page == slides.length - 1 ? finish : () => controller.nextPage(duration: const Duration(milliseconds: 350), curve: Curves.easeOut),
                    child: Text(page == slides.length - 1 ? 'ابدأ الآن' : 'التالي', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  final SharedPreferences prefs;
  final VoidCallback onThemeChanged;
  const MainNavigationScreen({super.key, required this.prefs, required this.onThemeChanged});
  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(prefs: widget.prefs, onOpenTab: (v) => setState(() => index = v)),
      QuranHubScreen(prefs: widget.prefs),
      const AzkarScreen(),
      MoreScreen(prefs: widget.prefs, onThemeChanged: widget.onThemeChanged),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: pages[index],
        bottomNavigationBar: SafeArea(
          top: false,
          child: Container(
            margin: const EdgeInsets.fromLTRB(10, 0, 10, 8),
            padding: const EdgeInsets.symmetric(vertical: 7),
            decoration: BoxDecoration(
              color: _navy,
              borderRadius: BorderRadius.circular(28),
              boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 18, offset: Offset(0, 8))],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _NavItem(icon: Icons.home_rounded, label: 'الرئيسية', selected: index == 0, onTap: () => setState(() => index = 0)),
                _NavItem(icon: Icons.menu_book_rounded, label: 'القرآن', selected: index == 1, onTap: () => setState(() => index = 1)),
                _NavItem(icon: Icons.auto_awesome_rounded, label: 'الأذكار', selected: index == 2, onTap: () => setState(() => index = 2)),
                _NavItem(icon: Icons.grid_view_rounded, label: 'المزيد', selected: index == 3, onTap: () => setState(() => index = 3)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(18),
    onTap: onTap,
    child: SizedBox(width: 66, child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: selected ? _gold : Colors.white60),
      const SizedBox(height: 2),
      Text(label, style: GoogleFonts.cairo(fontSize: 9, color: selected ? _gold : Colors.white60)),
    ])),
  );
}

class IslamicHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget? action;
  const IslamicHeader({super.key, required this.title, required this.subtitle, this.action});
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.fromLTRB(22, 52, 22, 28),
    decoration: const BoxDecoration(
      gradient: LinearGradient(colors: [_navy, _navy2], begin: Alignment.topRight, end: Alignment.bottomLeft),
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(36)),
    ),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: GoogleFonts.amiri(fontSize: 33, color: Colors.white, fontWeight: FontWeight.bold)),
        Text(subtitle, style: GoogleFonts.cairo(fontSize: 12, color: Colors.white70)),
      ])),
      if (action != null) action!,
    ]),
  );
}

class HomeScreen extends StatefulWidget {
  final SharedPreferences prefs;
  final ValueChanged<int> onOpenTab;
  const HomeScreen({super.key, required this.prefs, required this.onOpenTab});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final lastNumber = widget.prefs.getInt('lastSurahNumber');
    final lastName = widget.prefs.getString('lastSurahName');
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          IslamicHeader(
            title: 'السلام عليكم',
            subtitle: 'رفيقك اليومي للقرآن والذكر',
            action: Container(width: 52, height: 52, decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(18)), child: const Icon(Icons.nightlight_round, color: _gold)),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (lastNumber != null) _ContinueCard(number: lastNumber, name: lastName ?? 'السورة', prefs: widget.prefs),
              const SizedBox(height: 18),
              _PrayerCard(),
              const SizedBox(height: 22),
              Text('خدمات رفيق القرآن', style: GoogleFonts.amiri(fontSize: 25, fontWeight: FontWeight.bold, color: _navy)),
              const SizedBox(height: 10),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.35,
                children: [
                  _Feature(icon: Icons.menu_book_rounded, title: 'القرآن الكريم', subtitle: '114 سورة', onTap: () => widget.onOpenTab(1)),
                  _Feature(icon: Icons.auto_awesome_rounded, title: 'الأذكار', subtitle: 'صباح ومساء', onTap: () => widget.onOpenTab(2)),
                  _Feature(icon: Icons.timelapse_rounded, title: 'المسبحة', subtitle: 'سبّح الآن', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TasbihScreen()))),
                  _Feature(icon: Icons.format_quote_rounded, title: 'حديث اليوم', subtitle: 'كلمة نور', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyHadithScreen()))),
                ],
              ),
              const SizedBox(height: 16),
              _HourlyReminderCard(prefs: widget.prefs),
            ]),
          ),
        ],
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;
  const _Feature({required this.icon, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white,
    borderRadius: BorderRadius.circular(24),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: _gold, size: 30),
          const SizedBox(height: 7),
          Text(title, style: GoogleFonts.cairo(fontWeight: FontWeight.bold, color: _navy, fontSize: 13)),
          Text(subtitle, style: GoogleFonts.cairo(color: Colors.black45, fontSize: 10)),
        ]),
      ),
    ),
  );
}

class _ContinueCard extends StatelessWidget {
  final int number;
  final String name;
  final SharedPreferences prefs;
  const _ContinueCard({required this.number, required this.name, required this.prefs});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(gradient: const LinearGradient(colors: [_navy, _navy2]), borderRadius: BorderRadius.circular(28)),
    child: Row(children: [
      const Icon(Icons.menu_book_rounded, color: _gold, size: 42),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('تابع قراءتك', style: GoogleFonts.cairo(color: Colors.white70, fontSize: 12)),
        Text(name, style: GoogleFonts.amiri(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
      ])),
      IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SurahDetailScreen(number: number, name: name, prefs: prefs))), icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _gold)),
    ]),
  );
}

class _PrayerCard extends StatefulWidget {
  @override
  State<_PrayerCard> createState() => _PrayerCardState();
}
class _PrayerCardState extends State<_PrayerCard> {
  Future<Map<String, String>>? future;
  @override void initState() { super.initState(); future = load(); }
  Future<Map<String, String>> load() async {
    final uri = Uri.parse('https://api.aladhan.com/v1/timingsByCity?city=Cairo&country=Egypt&method=5');
    final r = await http.get(uri).timeout(const Duration(seconds: 15));
    final data = jsonDecode(r.body);
    final t = Map<String, dynamic>.from(data['data']['timings']);
    return {'الفجر': '${t['Fajr']}'.split(' ')[0], 'الظهر': '${t['Dhuhr']}'.split(' ')[0], 'العصر': '${t['Asr']}'.split(' ')[0], 'المغرب': '${t['Maghrib']}'.split(' ')[0], 'العشاء': '${t['Isha']}'.split(' ')[0]};
  }
  @override Widget build(BuildContext context) => FutureBuilder<Map<String,String>>(
    future: future,
    builder: (_, s) => Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 12)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Icon(Icons.mosque_rounded, color: _gold), const SizedBox(width: 8), Text('مواقيت الصلاة - القاهرة', style: GoogleFonts.amiri(fontSize: 22, fontWeight: FontWeight.bold, color: _navy)), const Spacer(), IconButton(onPressed: () => setState(() => future = load()), icon: const Icon(Icons.refresh_rounded))]),
        if (s.hasError) Text('تعذر تحميل المواقيت الآن', style: GoogleFonts.cairo(color: Colors.redAccent, fontSize: 11)) else if (!s.hasData) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()) else Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: s.data!.entries.map((e) => Column(children: [Text(e.key, style: GoogleFonts.cairo(fontSize: 10, color: Colors.black54)), Text(e.value, style: GoogleFonts.cairo(fontWeight: FontWeight.bold, color: _navy, fontSize: 12))])).toList()),
      ]),
    ),
  );
}

class _HourlyReminderCard extends StatefulWidget {
  final SharedPreferences prefs;
  const _HourlyReminderCard({required this.prefs});
  @override State<_HourlyReminderCard> createState() => _HourlyReminderCardState();
}
class _HourlyReminderCardState extends State<_HourlyReminderCard> {
  bool get enabled => widget.prefs.getBool('hourlyReminder') ?? true;
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: const Color(0xFFF1E5CB), borderRadius: BorderRadius.circular(24)),
    child: Row(children: [const Icon(Icons.favorite_rounded, color: _gold), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('تذكير بالصلاة على النبي ﷺ', style: GoogleFonts.cairo(fontWeight: FontWeight.bold, color: _navy, fontSize: 12)), Text('يمكنك تشغيل التذكير من الإعدادات', style: GoogleFonts.cairo(fontSize: 10, color: Colors.black54))])), Switch(value: enabled, onChanged: (v) async { await widget.prefs.setBool('hourlyReminder', v); setState(() {}); })]),
  );
}

class SurahListScreen extends StatelessWidget {
  const SurahListScreen({super.key});
  @override
  Widget build(BuildContext context) => const QuranHubScreen();
}

class QuranHubScreen extends StatefulWidget {
  final SharedPreferences? prefs;
  const QuranHubScreen({super.key, this.prefs});
  @override
  State<QuranHubScreen> createState() => _QuranHubScreenState();
}

class _QuranHubScreenState extends State<QuranHubScreen> {
  List<dynamic> all = [];
  List<dynamic> filtered = [];
  bool loading = true;
  String? error;
  String readerName = 'مشاري راشد العفاسي';
  String edition = 'ar.alafasy';
  String riwaya = 'حفص عن عاصم';

  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final r = await http.get(Uri.parse('https://api.alquran.cloud/v1/surah')).timeout(const Duration(seconds: 20));
      final d = jsonDecode(r.body);
      if (d['data'] is List) { all = List<dynamic>.from(d['data']); filtered = all; } else { error = 'تعذر تحميل السور'; }
    } catch (_) { error = 'تحقق من الإنترنت ثم حاول مرة أخرى'; }
    if (mounted) setState(() => loading = false);
  }
  void search(String q) { final v=q.trim().toLowerCase(); setState(() => filtered=v.isEmpty?all:all.where((x)=>'${x['name']} ${x['englishName']} ${x['number']}'.toLowerCase().contains(v)).toList()); }

  Future<void> pickReader() async {
    final result = await Navigator.push<Map<String,String>>(context, MaterialPageRoute(builder: (_) => const AudioEditionPickerScreen()));
    if (result != null && mounted) setState(() { readerName=result['name'] ?? readerName; edition=result['id'] ?? edition; riwaya=result['riwaya'] ?? riwaya; });
  }

  @override Widget build(BuildContext context) => Scaffold(
    body: Column(children: [
      IslamicHeader(title: 'القرآن الكريم', subtitle: 'اختر الرواية والقارئ ثم ابدأ رحلتك مع كتاب الله', action: const Icon(Icons.menu_book_rounded,color:_gold,size:34)),
      Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(24),boxShadow: const [BoxShadow(color:Colors.black12,blurRadius:12)]), child: Column(children: [
          Row(children:[const Icon(Icons.graphic_eq_rounded,color:_gold),const SizedBox(width:8),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(readerName,style:GoogleFonts.cairo(fontWeight:FontWeight.bold,color:_navy,fontSize:14)),Text('$riwaya • اضغط لتغيير القارئ أو الرواية',style:GoogleFonts.cairo(fontSize:9,color:Colors.black54))])),TextButton(onPressed:pickReader,child:const Text('تغيير'))]),
          const SizedBox(height:10),
          Row(children:[Expanded(child:_QuranQuick(icon:Icons.headphones_rounded,title:'القراء',onTap:pickReader)),const SizedBox(width:8),Expanded(child:_QuranQuick(icon:Icons.library_books_rounded,title:'الروايات',onTap:pickReader)),const SizedBox(width:8),Expanded(child:_QuranQuick(icon:Icons.bookmark_rounded,title:'آخر قراءة',onTap:(){ final p=widget.prefs; if(p!=null){ final n=p.getInt('lastSurahNumber'); final name=p.getString('lastSurahName'); if(n!=null) Navigator.push(context,MaterialPageRoute(builder:(_)=>SurahDetailScreen(number:n,name:name??'السورة',prefs:p,readerName:readerName,edition:edition,riwaya:riwaya))); }}))])
        ])),
        const SizedBox(height:12),
        TextField(onChanged:search,decoration:InputDecoration(prefixIcon:const Icon(Icons.search,color:_gold),hintText:'ابحث عن سورة...',filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none))),
      ])),
      Expanded(child: loading ? const Center(child:CircularProgressIndicator()) : error!=null ? Center(child:Text(error!)) : ListView.separated(padding:const EdgeInsets.fromLTRB(16,0,16,100),itemCount:filtered.length,separatorBuilder:(_,__)=>const SizedBox(height:8),itemBuilder:(_,i){final x=filtered[i]; return Material(color:Colors.white,borderRadius:BorderRadius.circular(18),child:ListTile(onTap:(){final p=widget.prefs ?? (context.findAncestorStateOfType<_MainNavigationScreenState>()?.widget.prefs); if(p!=null) Navigator.push(context,MaterialPageRoute(builder:(_)=>SurahDetailScreen(number:x['number'],name:x['name'],prefs:p,readerName:readerName,edition:edition,riwaya:riwaya)));},leading:CircleAvatar(backgroundColor:_cream,child:Text('${x['number']}',style:GoogleFonts.cairo(color:_navy,fontWeight:FontWeight.bold))),title:Text('${x['name']}',style:GoogleFonts.amiri(fontSize:24,fontWeight:FontWeight.bold,color:_navy)),subtitle:Text('${x['numberOfAyahs']} آية',style:GoogleFonts.cairo(fontSize:10)),trailing:const Icon(Icons.play_circle_fill_rounded,color:_gold,size:34)));}))
    ]),
  );
}

class _QuranQuick extends StatelessWidget { final IconData icon; final String title; final VoidCallback onTap; const _QuranQuick({required this.icon,required this.title,required this.onTap}); @override Widget build(BuildContext context)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(14),child:Container(padding:const EdgeInsets.symmetric(vertical:10),decoration:BoxDecoration(color:_cream,borderRadius:BorderRadius.circular(14)),child:Column(children:[Icon(icon,color:_navy,size:23),const SizedBox(height:3),Text(title,style:GoogleFonts.cairo(fontSize:9,fontWeight:FontWeight.bold,color:_navy))]))); }

class AudioEditionPickerScreen extends StatefulWidget { const AudioEditionPickerScreen({super.key}); @override State<AudioEditionPickerScreen> createState()=>_AudioEditionPickerScreenState(); }
class _AudioEditionPickerScreenState extends State<AudioEditionPickerScreen> {
  List<dynamic> all=[]; List<dynamic> filtered=[]; bool loading=true; String riwaya='الكل';
  final riwayat=['الكل','حفص عن عاصم','ورش عن نافع','قالون عن نافع','الدوري','السوسي'];
  @override void initState(){super.initState();load();}
  Future<void> load() async { try{final r=await http.get(Uri.parse('https://api.alquran.cloud/v1/edition?format=audio&language=ar')).timeout(const Duration(seconds:20));final d=jsonDecode(r.body);all=d['data'] is List?List<dynamic>.from(d['data']):[];filtered=all;}catch(_){} if(mounted)setState(()=>loading=false); }
  void apply(String q){final v=q.toLowerCase();setState(()=>filtered=all.where((e){final text='${e['name']} ${e['englishName']} ${e['identifier']}'.toLowerCase();final rv=riwaya=='الكل'||text.contains(riwaya.split(' ').first.toLowerCase());return rv&&(v.isEmpty||text.contains(v));}).toList());}
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:Text('اختيار القارئ والرواية',style:GoogleFonts.amiri(fontSize:26)),centerTitle:true),body:Column(children:[
    SizedBox(height:54,child:ListView.separated(scrollDirection:Axis.horizontal,padding:const EdgeInsets.all(8),itemCount:riwayat.length,separatorBuilder:(_,__)=>const SizedBox(width:6),itemBuilder:(_,i){final x=riwayat[i];return ChoiceChip(label:Text(x,style:GoogleFonts.cairo(fontSize:10)),selected:riwaya==x,onSelected:(_){setState(()=>riwaya=x);apply('');});})),
    Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:TextField(onChanged:apply,decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:'ابحث عن قارئ...',filled:true,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none)))),
    Expanded(child:loading?const Center(child:CircularProgressIndicator()):filtered.isEmpty?Center(child:Text('لا توجد نتيجة مطابقة، اعرض القائمة كاملة من «الكل»',style:GoogleFonts.cairo())):ListView.builder(itemCount:filtered.length,itemBuilder:(_,i){final e=filtered[i];final name='${e['name'] ?? e['englishName'] ?? e['identifier']}';return ListTile(leading:const CircleAvatar(backgroundColor:_cream,child:Icon(Icons.mic_rounded,color:_gold)),title:Text(name,style:GoogleFonts.cairo(fontWeight:FontWeight.bold)),subtitle:Text('${e['identifier']}',style:GoogleFonts.cairo(fontSize:9)),onTap:()=>Navigator.pop(context,{'name':name,'id':'${e['identifier']}','riwaya':riwaya=='الكل'?'حسب التسجيل المختار':riwaya}));}))
  ])));
}

class SurahDetailScreen extends StatefulWidget {
  final int number;
  final String name;
  final SharedPreferences prefs;
  final String readerName;
  final String edition;
  final String riwaya;

  const SurahDetailScreen({
    super.key,
    required this.number,
    required this.name,
    required this.prefs,
    this.readerName = 'مشاري راشد العفاسي',
    this.edition = 'ar.alafasy',
    this.riwaya = 'حفص عن عاصم',
  });

  @override
  State<SurahDetailScreen> createState() => _SurahDetailScreenState();
}

class _SurahDetailScreenState extends State<SurahDetailScreen> {
  late Future<List<dynamic>> future;
  double size = 29;
  bool playing = false;
  late AudioPlayer player;

  bool get favorite => widget.prefs
          .getStringList('favorites')
          ?.contains('${widget.number}|${widget.name}') ??
      false;

  @override
  void initState() {
    super.initState();
    widget.prefs.setInt('lastSurahNumber', widget.number);
    widget.prefs.setString('lastSurahName', widget.name);
    future = load();
    player = AudioPlayer();
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  Future<List<dynamic>> load() async {
    final response = await http
        .get(
          Uri.parse(
            'https://api.alquran.cloud/v1/surah/${widget.number}/quran-uthmani',
          ),
        )
        .timeout(const Duration(seconds: 20));
    final data = jsonDecode(response.body);

    if (response.statusCode != 200 || data['data']?['ayahs'] is! List) {
      throw Exception('تعذر تحميل السورة');
    }

    return List<dynamic>.from(data['data']['ayahs']);
  }

  Future<void> toggleFav() async {
    final key = '${widget.number}|${widget.name}';
    final list = [...(widget.prefs.getStringList('favorites') ?? [])];

    if (favorite) {
      list.remove(key);
    } else {
      list.add(key);
    }

    await widget.prefs.setStringList(
      'favorites',
      list.map((item) => item.toString()).toList(),
    );
    setState(() {});
  }

  Future<void> toggleAudio() async {
    if (playing) {
      await player.stop();
      if (mounted) setState(() => playing = false);
      return;
    }

    final number = widget.number.toString().padLeft(3, '0');
    await player.play(
      UrlSource(
        'https://cdn.islamic.network/quran/audio-surah/128/${widget.edition}/${widget.number}.mp3',
      ),
    );

    if (mounted) setState(() => playing = true);
  }

  void fontSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'حجم الخط',
              style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
            ),
            Slider(
              value: size,
              min: 20,
              max: 42,
              divisions: 11,
              onChanged: (value) => setState(() => size = value),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _cream,
        body: SafeArea(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [_navy, _navy2]),
                  borderRadius: BorderRadius.vertical(
                    bottom: Radius.circular(30),
                  ),
                ),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(
                        Icons.arrow_forward_ios,
                        color: Colors.white,
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Text(
                            widget.name,
                            style: GoogleFonts.amiri(
                              fontSize: 31,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'سورة من القرآن الكريم',
                            style: GoogleFonts.cairo(
                              fontSize: 10,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: fontSheet,
                      icon: const Icon(Icons.text_fields, color: _gold),
                    ),
                    IconButton(
                      onPressed: toggleFav,
                      icon: Icon(
                        favorite ? Icons.bookmark : Icons.bookmark_border,
                        color: _gold,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: FutureBuilder<List<dynamic>>(
                  future: future,
                  builder: (_, snapshot) {
                    if (snapshot.connectionState != ConnectionState.done) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    if (snapshot.hasError) {
                      return Center(
                        child: ElevatedButton(
                          onPressed: () => setState(() => future = load()),
                          child: const Text('إعادة المحاولة'),
                        ),
                      );
                    }

                    final ayahs = snapshot.data ?? [];
                    return SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(28),
                              border: Border.all(
                                color: _gold.withOpacity(.7),
                              ),
                            ),
                            child: Column(
                              children: [
                                Text(
                                  'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
                                  style: GoogleFonts.amiri(
                                    fontSize: 28,
                                    color: _navy,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    children: ayahs
                                        .map(
                                          (ayah) => TextSpan(
                                            text:
                                                '${ayah['text']} ﴿${ayah['numberInSurah']}﴾ ',
                                            style: GoogleFonts.amiri(
                                              fontSize: size,
                                              height: 2.05,
                                              color: _navy,
                                            ),
                                          ),
                                        )
                                        .toList(),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 90),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Container(
                margin: const EdgeInsets.all(12),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: const [
                    BoxShadow(color: Colors.black12, blurRadius: 14),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: const BoxDecoration(
                        color: _cream,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.person, color: _navy),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.readerName,
                            style: GoogleFonts.cairo(
                              fontWeight: FontWeight.bold,
                              fontSize: 11,
                              color: _navy,
                            ),
                          ),
                          Text(
                            widget.riwaya,
                            style: GoogleFonts.cairo(
                              fontSize: 9,
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: toggleAudio,
                      icon: Icon(
                        playing
                            ? Icons.stop_circle_rounded
                            : Icons.play_circle_fill_rounded,
                        size: 46,
                        color: _navy,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AzkarScreen extends StatelessWidget {
  const AzkarScreen({super.key});

  // مجموعة موسعة من الأذكار اليومية داخل التطبيق حتى لا تكون الصفحة تجريبية.
  static const Map<String, List<String>> data = {
    'أذكار الصباح': [
      'أصبحنا وأصبح الملك لله والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
      'اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور.',
      'رضيت بالله ربًا، وبالإسلام دينًا، وبمحمد ﷺ نبيًا.',
      'اللهم إني أصبحت أشهدك وأشهد حملة عرشك وملائكتك وجميع خلقك أنك أنت الله لا إله إلا أنت وحدك لا شريك لك وأن محمدًا عبدك ورسولك.',
      'اللهم ما أصبح بي من نعمة أو بأحد من خلقك فمنك وحدك لا شريك لك، فلك الحمد ولك الشكر.',
      'حسبي الله لا إله إلا هو عليه توكلت وهو رب العرش العظيم.',
      'بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم.',
      'أعوذ بكلمات الله التامات من شر ما خلق.',
      'سبحان الله وبحمده.',
      'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
      'اللهم إني أسألك العفو والعافية في الدنيا والآخرة.',
      'يا حي يا قيوم برحمتك أستغيث، أصلح لي شأني كله ولا تكلني إلى نفسي طرفة عين.',
      'أصبحنا على فطرة الإسلام، وعلى كلمة الإخلاص، وعلى دين نبينا محمد ﷺ، وعلى ملة أبينا إبراهيم حنيفًا مسلمًا وما كان من المشركين.',
    ],
    'أذكار المساء': [
      'أمسينا وأمسى الملك لله والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
      'اللهم بك أمسينا وبك أصبحنا وبك نحيا وبك نموت وإليك المصير.',
      'رضيت بالله ربًا، وبالإسلام دينًا، وبمحمد ﷺ نبيًا.',
      'اللهم إني أمسيت أشهدك وأشهد حملة عرشك وملائكتك وجميع خلقك أنك أنت الله لا إله إلا أنت وحدك لا شريك لك وأن محمدًا عبدك ورسولك.',
      'اللهم ما أمسى بي من نعمة أو بأحد من خلقك فمنك وحدك لا شريك لك، فلك الحمد ولك الشكر.',
      'حسبي الله لا إله إلا هو عليه توكلت وهو رب العرش العظيم.',
      'بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم.',
      'أعوذ بكلمات الله التامات من شر ما خلق.',
      'سبحان الله وبحمده.',
      'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
      'اللهم إني أسألك العفو والعافية في الدنيا والآخرة.',
      'أمسينا على فطرة الإسلام، وعلى كلمة الإخلاص، وعلى دين نبينا محمد ﷺ، وعلى ملة أبينا إبراهيم حنيفًا مسلمًا وما كان من المشركين.',
    ],
    'أذكار بعد الصلاة': [
      'أستغفر الله.',
      'اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام.',
      'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
      'اللهم لا مانع لما أعطيت ولا معطي لما منعت ولا ينفع ذا الجد منك الجد.',
      'سبحان الله.',
      'الحمد لله.',
      'الله أكبر.',
      'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
    ],
    'أذكار النوم': [
      'باسمك اللهم أموت وأحيا.',
      'اللهم أسلمت نفسي إليك، وفوضت أمري إليك، ووجهت وجهي إليك، وألجأت ظهري إليك، رغبة ورهبة إليك، لا ملجأ ولا منجى منك إلا إليك.',
      'باسمك ربي وضعت جنبي وبك أرفعه، فإن أمسكت نفسي فارحمها وإن أرسلتها فاحفظها بما تحفظ به عبادك الصالحين.',
      'سبحان الله.',
      'الحمد لله.',
      'الله أكبر.',
      'آية الكرسي.',
      'الإخلاص والفلق والناس.',
    ],
    'أذكار الاستيقاظ': [
      'الحمد لله الذي أحيانا بعدما أماتنا وإليه النشور.',
      'الحمد لله الذي عافاني في جسدي ورد علي روحي وأذن لي بذكره.',
      'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
    ],
    'أذكار دخول المنزل والخروج منه': [
      'بسم الله ولجنا وبسم الله خرجنا وعلى ربنا توكلنا.',
      'اللهم إني أعوذ بك أن أضل أو أزل أو أظلم أو أُظلم أو أجهل أو يُجهل علي.',
      'بسم الله، توكلت على الله، ولا حول ولا قوة إلا بالله.',
    ],
    'أذكار الطعام': [
      'بسم الله.',
      'الحمد لله الذي أطعمني هذا ورزقنيه من غير حول مني ولا قوة.',
      'الحمد لله حمدًا كثيرًا طيبًا مباركًا فيه، غير مكفي ولا مودع ولا مستغنى عنه ربنا.',
    ],
    'أذكار المسجد': [
      'اللهم افتح لي أبواب رحمتك.',
      'اللهم إني أسألك من فضلك.',
      'أعوذ بالله العظيم وبوجهه الكريم وسلطانه القديم من الشيطان الرجيم.',
    ],
    'أدعية جامعة': [
      'ربنا آتنا في الدنيا حسنة وفي الآخرة حسنة وقنا عذاب النار.',
      'ربنا لا تؤاخذنا إن نسينا أو أخطأنا.',
      'ربنا أفرغ علينا صبرًا وثبت أقدامنا.',
      'رب اشرح لي صدري ويسر لي أمري.',
      'رب زدني علمًا.',
      'اللهم إنك عفو كريم تحب العفو فاعف عنا.',
      'اللهم إني أسألك الهدى والتقى والعفاف والغنى.',
      'اللهم أصلح لي ديني الذي هو عصمة أمري، وأصلح لي دنياي التي فيها معاشي، وأصلح لي آخرتي التي إليها معادي.',
      'يا مقلب القلوب ثبت قلبي على دينك.',
      'اللهم أعني على ذكرك وشكرك وحسن عبادتك.',
    ],
    'أدعية الكرب والهم': [
      'لا إله إلا أنت سبحانك إني كنت من الظالمين.',
      'حسبي الله ونعم الوكيل.',
      'لا حول ولا قوة إلا بالله.',
      'اللهم رحمتك أرجو فلا تكلني إلى نفسي طرفة عين.',
      'يا حي يا قيوم برحمتك أستغيث.',
    ],
  };

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Column(
          children: [
            IslamicHeader(
              title: 'الأذكار',
              subtitle: 'أذكار يومية متنوعة لتبقى قريبًا من الله',
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                children: data.entries
                    .map((entry) => _ZikrCategory(
                          title: entry.key,
                          items: entry.value,
                        ))
                    .toList(),
              ),
            ),
          ],
        ),
      );
}

class _ZikrCategory extends StatelessWidget {
  final String title;
  final List<String> items;

  const _ZikrCategory({required this.title, required this.items});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
        ),
        child: ExpansionTile(
          leading: const Icon(Icons.auto_awesome_rounded, color: _gold),
          title: Text(
            title,
            style: GoogleFonts.amiri(
              fontSize: 23,
              fontWeight: FontWeight.bold,
              color: _navy,
            ),
          ),
          children: items.map((item) => _ZikrItem(text: item)).toList(),
        ),
      );
}

class _ZikrItem extends StatefulWidget {
  final String text;
  const _ZikrItem({required this.text});

  @override
  State<_ZikrItem> createState() => _ZikrItemState();
}

class _ZikrItemState extends State<_ZikrItem> {
  int done = 0;
  int get target {
    if (widget.text.contains('رضيت بالله')) return 3;
    if (widget.text.contains('بسم الله الذي لا يضر')) return 3;
    if (widget.text.contains('حسبي الله')) return 7;
    if (widget.text == 'أستغفر الله.') return 3;
    if (widget.text == 'سبحان الله.' || widget.text == 'الحمد لله.' || widget.text == 'الله أكبر.') return 33;
    return 1;
  }
  void tap(){ if(done<target) setState(()=>done++); }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
        child: InkWell(
          onTap: tap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _cream,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              children: [
                Text(
                  widget.text,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.amiri(
                    fontSize: 22,
                    height: 1.8,
                    color: _navy,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  done >= target ? '✓ تم الذكر' : 'المتبقي: ${target - done} من $target',
                  style: GoogleFonts.cairo(fontSize: 10, color: _gold),
                ),
              ],
            ),
          ),
        ),
      );
}

class TasbihScreen extends StatefulWidget { const TasbihScreen({super.key}); @override State<TasbihScreen> createState()=>_TasbihScreenState(); }
class _TasbihScreenState extends State<TasbihScreen> { int count=0; int target=33; String phrase='سبحان الله'; final phrases=['سبحان الله','الحمد لله','الله أكبر','لا إله إلا الله','أستغفر الله']; void tap(){setState(()=>count++);} @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(backgroundColor:const Color(0xFF4B321A),appBar:AppBar(backgroundColor:const Color(0xFF4B321A),foregroundColor:_gold,title:Text('السبحة الإلكترونية',style:GoogleFonts.amiri(fontSize:29,fontWeight:FontWeight.bold))),body:Column(children:[Padding(padding:const EdgeInsets.all(16),child:Row(children:[Expanded(child:DropdownButtonFormField<String>(value:phrase,decoration:InputDecoration(filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none)),items:phrases.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>phrase=v??phrase))),const SizedBox(width:10),DropdownButton<int>(value:target,items:[33,99,100,1000].map((x)=>DropdownMenuItem(value:x,child:Text('$x'))).toList(),onChanged:(v)=>setState(()=>target=v??target))])),Expanded(child:GestureDetector(onTap:tap,child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Container(width:250,height:250,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.white,boxShadow:const [BoxShadow(color:Colors.black45,blurRadius:25)]),child:Center(child:Text('$count',style:GoogleFonts.cairo(fontSize:64,fontWeight:FontWeight.bold,color:_navy)))),const SizedBox(height:28),...List.generate(2,(i)=>Container(width:76,height:76,margin:const EdgeInsets.symmetric(vertical:8),decoration:BoxDecoration(shape:BoxShape.circle,gradient:const LinearGradient(colors:[Color(0xFFF4D27C),Color(0xFF9C6B1D)]),boxShadow:const [BoxShadow(color:Colors.black38,blurRadius:12)]))),Container(width:6,height:160,color:const Color(0xFFEAD6A3))])))),Container(width:double.infinity,padding:const EdgeInsets.all(18),decoration:const BoxDecoration(color:Color(0xFFF7F2E8),borderRadius:BorderRadius.vertical(top:Radius.circular(30))),child:Column(children:[Text(phrase,style:GoogleFonts.amiri(fontSize:30,fontWeight:FontWeight.bold,color:_navy)),Text('الهدف $target • ${count>=target?'أكملت الهدف ✓':'اضغط على السبحة'}',style:GoogleFonts.cairo(color:_navy2)),TextButton.icon(onPressed:()=>setState(()=>count=0),icon:const Icon(Icons.refresh),label:const Text('إعادة الضبط'))]))]))); }


class MoreScreen extends StatelessWidget {
  final SharedPreferences prefs; final VoidCallback onThemeChanged;
  const MoreScreen({super.key,required this.prefs,required this.onThemeChanged});
  @override Widget build(BuildContext context){ final items=<_MoreItem>[
    _MoreItem('القرآن الكريم',Icons.menu_book_rounded,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>QuranHubScreen(prefs:prefs)))),
    _MoreItem('أسماء الله الحسنى',Icons.auto_awesome_rounded,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AsmaAllahScreen()))),
    _MoreItem('السبحة الإلكترونية',Icons.timelapse_rounded,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const TasbihScreen()))),
    _MoreItem('اتجاه القبلة',Icons.explore_rounded,()=>_soon(context,'اتجاه القبلة')),
    _MoreItem('المساجد القريبة',Icons.mosque_rounded,()=>_soon(context,'المساجد القريبة')),
    _MoreItem('مواقيت الصلاة',Icons.access_time_filled_rounded,()=>_soon(context,'مواقيت الصلاة')),
    _MoreItem('التقويم الهجري',Icons.calendar_month_rounded,()=>_soon(context,'التقويم الهجري')),
    _MoreItem('ورد القرآن',Icons.bookmark_added_rounded,()=>_soon(context,'ورد القرآن')),
    _MoreItem('المفضلة',Icons.favorite_rounded,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>FavoritesScreen(prefs:prefs)))),
    _MoreItem('الإعدادات',Icons.settings_rounded,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SettingsScreen(prefs:prefs,onChanged:onThemeChanged)))),
  ]; return Scaffold(body:Column(children:[IslamicHeader(title:'أدوات ومزايا',subtitle:'كل ما تحتاجه في رفيق القرآن'),Expanded(child:GridView.builder(padding:const EdgeInsets.fromLTRB(16,16,16,100),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,mainAxisSpacing:18,crossAxisSpacing:12,childAspectRatio:.82),itemCount:items.length,itemBuilder:(_,i){final x=items[i];return InkWell(onTap:x.onTap,borderRadius:BorderRadius.circular(40),child:Column(children:[Container(width:86,height:86,decoration:BoxDecoration(shape:BoxShape.circle,color:_cream,boxShadow:const [BoxShadow(color:Colors.black12,blurRadius:10)]),child:Icon(x.icon,size:43,color:_navy)),const SizedBox(height:7),Text(x.title,textAlign:TextAlign.center,style:GoogleFonts.cairo(fontWeight:FontWeight.bold,fontSize:11,color:_navy))]));}))])); }
  void _soon(BuildContext c,String title)=>ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('$title سيتم تطويره داخل النسخة القادمة')));
}
class _MoreItem { final String title; final IconData icon; final VoidCallback onTap; _MoreItem(this.title,this.icon,this.onTap); }

class AsmaAllahScreen extends StatelessWidget {
  const AsmaAllahScreen({super.key});
  static const names=[
    ['الرحمن','Ar-Rahman','كثير الرحمة، وسعت رحمته كل شيء.'],
    ['الرحيم','Ar-Rahim','المنعم المتفضل، الذي تتجدد رحمته بعباده.'],
    ['الملك','Al-Malik','مالك الملك كله والمتصرف فيه.'],
    ['القدوس','Al-Quddus','المنزه عن العيوب والنقائص.'],
    ['السلام','As-Salam','السالم من كل نقص وعيب، وناشر السلام.'],
    ['المؤمن','Al-Mu-min','المؤمِّن لعباده، والمصدق لرسله.'],
    ['المهيمن','Al-Muhaymin','الرقيب الحافظ الشهيد على خلقه.'],
    ['العزيز','Al-Aziz','الغالب القوي الذي لا يُغلب.'],
    ['الجبار','Al-Jabbar','العظيم الذي يجبر كسر الضعفاء.'],
    ['المتكبر','Al-Mutakabbir','المتعالي المتفرد بالعظمة والكبرياء.'],
    ['الخالق','Al-Khaliq','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['البارئ','Al-Bari','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المصور','Al-Musawwir','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الغفار','Al-Ghaffar','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['القهار','Al-Qahhar','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الوهاب','Al-Wahhab','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الرزاق','Ar-Razzaq','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الفتاح','Al-Fattah','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['العليم','Al-Alim','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['القابض','Al-Qabid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الباسط','Al-Basit','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الخافض','Al-Khafid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الرافع','Ar-Rafi','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المعز','Al-Muizz','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المذل','Al-Mudhill','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['السميع','As-Sami','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['البصير','Al-Basir','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الحكم','Al-Hakam','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['العدل','Al-Adl','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['اللطيف','Al-Latif','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الخبير','Al-Khabir','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الحليم','Al-Halim','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['العظيم','Al-Azim','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الغفور','Al-Ghafur','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الشكور','Ash-Shakur','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['العلي','Al-Ali','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الكبير','Al-Kabir','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الحفيظ','Al-Hafiz','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المقيت','Al-Muqit','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الحسيب','Al-Hasib','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الجليل','Al-Jalil','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الكريم','Al-Karim','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الرقيب','Ar-Raqib','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المجيب','Al-Mujib','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الواسع','Al-Wasi','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الحكيم','Al-Hakim','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الودود','Al-Wadud','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المجيد','Al-Majid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الباعث','Al-Baith','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الشهيد','Ash-Shahid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الحق','Al-Haqq','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الوكيل','Al-Wakil','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['القوي','Al-Qawiyy','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المتين','Al-Matin','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الولي','Al-Waliyy','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الحميد','Al-Hamid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المحصي','Al-Muhsi','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المبدئ','Al-Mubdi','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المعيد','Al-Muid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المحيي','Al-Muhyi','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المميت','Al-Mumit','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الحي','Al-Hayy','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['القيوم','Al-Qayyum','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الواجد','Al-Wajid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الماجد','Al-Majid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الواحد','Al-Wahid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الأحد','Al-Ahad','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الصمد','As-Samad','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['القادر','Al-Qadir','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المقتدر','Al-Muqtadir','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المقدم','Al-Muqaddim','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المؤخر','Al-Muakhkhir','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الأول','Al-Awwal','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الآخر','Al-Akhir','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الظاهر','Az-Zahir','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الباطن','Al-Batin','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الوالي','Al-Wali','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المتعالي','Al-Mutaali','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['البر','Al-Barr','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['التواب','At-Tawwab','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المنتقم','Al-Muntaqim','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['العفو','Al-Afuww','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الرؤوف','Ar-Rauf','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['مالك الملك','Malik Al-Mulk','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['ذو الجلال والإكرام','Dhul-Jalali wal-Ikram','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المقسط','Al-Muqsit','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الجامع','Al-Jami','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الغني','Al-Ghani','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المغني','Al-Mughni','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['المانع','Al-Mani','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الضار','Ad-Darr','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['النافع','An-Nafi','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['النور','An-Nur','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الهادي','Al-Hadi','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['البديع','Al-Badi','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الباقي','Al-Baqi','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الوارث','Al-Warith','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الرشيد','Ar-Rashid','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
    ['الصبور','As-Sabur','من أسماء الله الحسنى، يُتأمل معناها ويُدعى الله سبحانه وتعالى بها.'],
  ];  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFF4B321A),
        appBar: AppBar(
          backgroundColor: const Color(0xFF4B321A),
          foregroundColor: _gold,
          title: Text('أسماء الله الحسنى', style: GoogleFonts.amiri(fontSize: 30, fontWeight: FontWeight.bold)),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 90),
          children: [
            Text('أسماء الله الحسنى', textAlign: TextAlign.center, style: GoogleFonts.amiri(fontSize: 31, color: _gold, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text('قال الله تعالى: ﴿وَلِلَّهِ الْأَسْمَاءُ الْحُسْنَىٰ فَادْعُوهُ بِهَا﴾', textAlign: TextAlign.center, style: GoogleFonts.amiri(fontSize: 22, height: 1.8, color: Colors.white)),
            const SizedBox(height: 24),
            ...List.generate(names.length, (i) {
              final n = names[i];
              return Padding(
                padding: const EdgeInsets.only(bottom: 28),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(color: _cream, borderRadius: BorderRadius.circular(18)),
                        child: Text(n[2], textAlign: TextAlign.center, style: GoogleFonts.cairo(fontWeight: FontWeight.bold, fontSize: 13, height: 1.8, color: _navy)),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Container(
                      width: 128,
                      height: 128,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: _gold, width: 3)),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('${i + 1}-${n[0]}', style: GoogleFonts.cairo(fontSize: 15, fontWeight: FontWeight.bold, color: _navy)),
                            Text(n[1], style: GoogleFonts.cairo(fontSize: 12, fontWeight: FontWeight.bold, color: _navy)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

}

class DailyHadithScreen extends StatefulWidget { const DailyHadithScreen({super.key}); @override State<DailyHadithScreen> createState()=>_DailyHadithScreenState(); }
class _DailyHadithScreenState extends State<DailyHadithScreen>{int i=0;final h=const [('إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.','متفق عليه'),('من كان يؤمن بالله واليوم الآخر فليقل خيرًا أو ليصمت.','رواه البخاري ومسلم'),('خيركم من تعلم القرآن وعلمه.','رواه البخاري'),('لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.','متفق عليه')];@override Widget build(BuildContext context)=>Scaffold(body:Column(children:[IslamicHeader(title:'حديث اليوم',subtitle:'كلمة نور ترافق يومك'),Expanded(child:Center(child:Padding(padding:const EdgeInsets.all(22),child:Container(width:double.infinity,padding:const EdgeInsets.all(28),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(30)),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.format_quote_rounded,size:56,color:_gold),Text(h[i].$1,textAlign:TextAlign.center,style:GoogleFonts.amiri(fontSize:29,height:1.8,color:_navy)),const SizedBox(height:12),Text(h[i].$2,style:GoogleFonts.cairo(fontSize:11,color:Colors.black54)),const SizedBox(height:20),ElevatedButton.icon(style:ElevatedButton.styleFrom(backgroundColor:_navy,foregroundColor:Colors.white),onPressed:()=>setState(()=>i=(i+1)%h.length),icon:const Icon(Icons.refresh),label:const Text('حديث آخر'))])))))]));}

class FavoritesScreen extends StatefulWidget { final SharedPreferences prefs; const FavoritesScreen({super.key,required this.prefs}); @override State<FavoritesScreen> createState()=>_FavoritesScreenState(); }
class _FavoritesScreenState extends State<FavoritesScreen>{@override Widget build(BuildContext context){final list=widget.prefs.getStringList('favorites')??[];return Scaffold(body:Column(children:[IslamicHeader(title:'المفضلة',subtitle:'السور التي اخترتها للعودة إليها سريعًا'),Expanded(child:list.isEmpty?Center(child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.bookmark_border_rounded,size:60,color:_gold),const SizedBox(height:10),Text('لا توجد سور في المفضلة بعد',style:GoogleFonts.cairo(color:Colors.black54))])):ListView.builder(padding:const EdgeInsets.all(16),itemCount:list.length,itemBuilder:(_,i){final p=list[i].split('|');return Card(child:ListTile(leading:CircleAvatar(backgroundColor:_cream,child:Text(p[0])),title:Text(p.length>1?p[1]:'سورة',style:GoogleFonts.amiri(fontSize:23,color:_navy)),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{list.removeAt(i);await widget.prefs.setStringList('favorites',list);setState((){});}),onTap:(){if(p.length>1)Navigator.push(context,MaterialPageRoute(builder:(_)=>SurahDetailScreen(number:int.parse(p[0]),name:p[1],prefs:widget.prefs)));}));}))]));}}

class SettingsScreen extends StatefulWidget { final SharedPreferences prefs; final VoidCallback onChanged; const SettingsScreen({super.key,required this.prefs,required this.onChanged}); @override State<SettingsScreen> createState()=>_SettingsScreenState(); }
class _SettingsScreenState extends State<SettingsScreen>{bool get dark=>widget.prefs.getBool('dark')??false;bool get hourly=>widget.prefs.getBool('hourlyReminder')??true;Future<void> setBool(String k,bool v)async{await widget.prefs.setBool(k,v);setState((){});widget.onChanged();}@override Widget build(BuildContext context)=>Scaffold(body:Column(children:[IslamicHeader(title:'الإعدادات',subtitle:'خصص تجربتك داخل رفيق القرآن'),Expanded(child:ListView(padding:const EdgeInsets.fromLTRB(16,16,16,100),children:[_SettingTile(icon:Icons.dark_mode_rounded,title:'الوضع الداكن',subtitle:'تغيير ألوان التطبيق',value:dark,onChanged:(v)=>setBool('dark',v)),_SettingTile(icon:Icons.notifications_active_rounded,title:'تذكير بالصلاة على النبي ﷺ',subtitle:'تفعيل التذكير داخل التطبيق',value:hourly,onChanged:(v)=>setBool('hourlyReminder',v)),ListTile(leading:const Icon(Icons.info_outline,color:_gold),title:Text('عن التطبيق',style:GoogleFonts.cairo(fontWeight:FontWeight.bold,color:_navy)),subtitle:Text('رفيق القرآن • الإصدار 2.0.0',style:GoogleFonts.cairo(fontSize:10)),onTap:()=>showAboutDialog(context:context,applicationName:'رفيق القرآن',applicationVersion:'2.0.0',children:[Text('تطبيق عربي للقرآن الكريم والأذكار ومواقيت الصلاة.')]))]))]));}
class _SettingTile extends StatelessWidget{final IconData icon;final String title,subtitle;final bool value;final ValueChanged<bool> onChanged;const _SettingTile({required this.icon,required this.title,required this.subtitle,required this.value,required this.onChanged});@override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.only(bottom:10),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(20)),child:SwitchListTile(secondary:Icon(icon,color:_gold),title:Text(title,style:GoogleFonts.cairo(fontWeight:FontWeight.bold,color:_navy,fontSize:13)),subtitle:Text(subtitle,style:GoogleFonts.cairo(fontSize:10,color:Colors.black54)),value:value,onChanged:onChanged));}
