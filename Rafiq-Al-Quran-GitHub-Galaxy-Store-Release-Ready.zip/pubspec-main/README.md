# رفيق القرآن

تطبيق إسلامي عربي يضم القرآن الكريم، الأذكار، السبحة الإلكترونية، أسماء الله الحسنى، والمزيد من الأدوات.

## النشر والبناء
- اسم التطبيق: رفيق القرآن
- Flutter package: `rafiq_al_quran`
- Android applicationId: `com.rafiqalquran.app`
- الإصدار الحالي: `2.2.0+4`

### التوقيع الآمن عبر GitHub Actions
لا ترفع ملف الـKeystore أو كلمات مروره إلى GitHub. أضفها فقط إلى GitHub Actions Secrets:
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

الـworkflow يبني APK وAAB. إذا كانت الأسرار موجودة، ينتج إصدار Release موقّع؛ وإذا لم تكن موجودة، ينتج إصدارًا غير موقّع للاختبار فقط.

## مهم قبل أول نشر
لا تغيّر `applicationId` أو مفتاح التوقيع بعد نشر أول إصدار؛ لأن التحديثات اللاحقة يجب أن تحافظ على هوية التطبيق والتوقيع.

راجع:
- `docs/privacy_policy.html`
- `TERMS_OF_USE_AR.md`
- `STORE_LISTING_AR.md`
- `SECURITY.md`
